// CSCI 1851 Fall 2023
// Lab 05 Problem 5
// Nhi Pham

public class StringUtil{
	static String toString(double data){
		return String.valueOf(data);
	}

	static String toString(float data){
		return String.valueOf(data);
	}

	static String toString(int data){
		return String.valueOf(data);
	}

	static String toString(long data){
		return String.valueOf(data);
	}

	static String toString(char data){
		return String.valueOf(data);
	}

	static String toString(boolean data){
		return String.valueOf(data);
	}
}