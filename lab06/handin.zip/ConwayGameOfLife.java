// Lab 6
// Problem 9
// due 10/26 Thu

public class ConwayGameOfLife{
    public static boolean[][] update(boolean[][] grid){

    }

    public static int countNeighbors(int i; int j; boolean[][] grid){
        
    }
}